<?php

function AfficherPageAccueil()
{
    require 'vue/Accueil.php';
}

function AfficherPageConnexion()
{
    require 'vue/Connexion.php';
}

function Deconnecter()
{
}

function Connecter()
{
}